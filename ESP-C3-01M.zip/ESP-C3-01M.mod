PCBNEW-LibModule-V1  
# encoding utf-8
Units mm
$INDEX
XCVR_ESP-C3-01M
$EndINDEX
$MODULE XCVR_ESP-C3-01M
Po 0 0 0 15 00000000 00000000 ~~
Li XCVR_ESP-C3-01M
Cd 
Sc 00000000
At SMD
Op 0 0 0
.SolderMask 0
.SolderPaste 0
T0 -6.46 -3.7575 1 1 0 0.05 N V 21 "XCVR_ESP-C3-01M"
T1 -5.795 1.905 1 1 0 0.05 N V 21 "VAL**"
DP 0 0 0 0 4 0 28
Dl -7.53 -0.45
Dl 7.37 -0.45
Dl 7.37 0.45
Dl -7.53 0.45
DS -9 -2.4 9 -2.4 0.127 27
DS 9 -2.4 9 0.4 0.127 27
DS 9 0.4 -9 0.4 0.127 27
DS -9 0.4 -9 -2.4 0.127 27
DS -9.25 -2.65 -9.25 0.7 0.05 26
DS -9.25 0.7 9.25 0.7 0.05 26
DS 9.25 0.7 9.25 -2.65 0.05 26
DS 9.25 -2.65 -9.25 -2.65 0.05 26
DS -7.78 -1.9 7.62 -1.9 0.05 27
DS 7.62 -1.9 7.62 1.9 0.05 27
DS 7.62 1.9 -7.78 1.9 0.05 27
DS -7.78 1.9 -7.78 -1.9 0.05 27
DS -9 -2.4 9 -2.4 0.127 21
DS 9 -2.4 9 0.4 0.127 21
DS -9 0.4 -9 -2.4 0.127 21
DC 6.26 -3.2 6.36 -3.2 0.2 21
DC 6.26 -3.2 6.36 -3.2 0.2 27
DS -7.85 0.4 -9 0.4 0.127 21
DS 9 0.4 7.69 0.4 0.127 21
$PAD
Sh "1" R 0.8 1.2 0 0 0
At SMD N 00040001
.SolderMask 0
.SolderPaste 0
Ne 0 ""
Po 6.26 -1.05
$EndPAD
$PAD
Sh "2" R 0.8 1.2 0 0 0
At SMD N 00040001
.SolderMask 0
.SolderPaste 0
Ne 0 ""
Po 4.66 -1.05
$EndPAD
$PAD
Sh "3" R 0.8 1.2 0 0 0
At SMD N 00040001
.SolderMask 0
.SolderPaste 0
Ne 0 ""
Po 3.06 -1.05
$EndPAD
$PAD
Sh "4" R 0.8 1.2 0 0 0
At SMD N 00040001
.SolderMask 0
.SolderPaste 0
Ne 0 ""
Po 1.46 -1.05
$EndPAD
$PAD
Sh "5" R 0.8 1.2 0 0 0
At SMD N 00040001
.SolderMask 0
.SolderPaste 0
Ne 0 ""
Po -0.14 -1.05
$EndPAD
$PAD
Sh "6" R 0.8 1.2 0 0 0
At SMD N 00040001
.SolderMask 0
.SolderPaste 0
Ne 0 ""
Po -1.74 -1.05
$EndPAD
$PAD
Sh "7" R 0.8 1.2 0 0 0
At SMD N 00040001
.SolderMask 0
.SolderPaste 0
Ne 0 ""
Po -3.34 -1.05
$EndPAD
$PAD
Sh "8" R 0.8 1.2 0 0 0
At SMD N 00040001
.SolderMask 0
.SolderPaste 0
Ne 0 ""
Po -4.94 -1.05
$EndPAD
$PAD
Sh "9" R 0.8 1.2 0 0 0
At SMD N 00040001
.SolderMask 0
.SolderPaste 0
Ne 0 ""
Po -6.54 -1.05
$EndPAD
$PAD
Sh "10" R 0.8 1.2 0 0 0
At SMD N 00040001
.SolderMask 0
.SolderPaste 0
Ne 0 ""
Po -6.54 1.05
$EndPAD
$PAD
Sh "11" R 0.8 1.2 0 0 0
At SMD N 00040001
.SolderMask 0
.SolderPaste 0
Ne 0 ""
Po -4.94 1.05
$EndPAD
$PAD
Sh "12" R 0.8 1.2 0 0 0
At SMD N 00040001
.SolderMask 0
.SolderPaste 0
Ne 0 ""
Po -3.34 1.05
$EndPAD
$PAD
Sh "13" R 0.8 1.2 0 0 0
At SMD N 00040001
.SolderMask 0
.SolderPaste 0
Ne 0 ""
Po -1.74 1.05
$EndPAD
$PAD
Sh "14" R 0.8 1.2 0 0 0
At SMD N 00040001
.SolderMask 0
.SolderPaste 0
Ne 0 ""
Po -0.14 1.05
$EndPAD
$PAD
Sh "15" R 0.8 1.2 0 0 0
At SMD N 00040001
.SolderMask 0
.SolderPaste 0
Ne 0 ""
Po 1.46 1.05
$EndPAD
$PAD
Sh "16" R 0.8 1.2 0 0 0
At SMD N 00040001
.SolderMask 0
.SolderPaste 0
Ne 0 ""
Po 3.06 1.05
$EndPAD
$PAD
Sh "17" R 0.8 1.2 0 0 0
At SMD N 00040001
.SolderMask 0
.SolderPaste 0
Ne 0 ""
Po 4.66 1.05
$EndPAD
$PAD
Sh "18" R 0.8 1.2 0 0 0
At SMD N 00040001
.SolderMask 0
.SolderPaste 0
Ne 0 ""
Po 6.26 1.05
$EndPAD
$EndMODULE XCVR_ESP-C3-01M
